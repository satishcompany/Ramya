Beers-of-the-World
==================

A java web app, listing all kinds of beer